import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import { PremiumCalculator } from '../premium-calculator/premium-calculator.component';

describe('PremiumCalculator', () => {
  let component: PremiumCalculator;
  let fixture: ComponentFixture<PremiumCalculator>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PremiumCalculator],
      imports: [
        ReactiveFormsModule,
        FormsModule
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PremiumCalculator);
    component = fixture.componentInstance;
    component.ngOnInit();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('form invalid when empty', () => {
    expect(component.form.valid).toBeFalsy();
  });

  it('name field validity', () => {
    let name = component.form.controls['name'];
    expect(name.valid).toBeFalsy();

    let errors = {};
    name.setValue("");
    errors = name.errors || {};
    expect(errors['required']).toBeTruthy();     
  });

  it('age field validity', () => {
    let age = component.form.controls['age'];
    expect(age.valid).toBeFalsy();

    let errors = {};
    age.setValue("");
    errors = age.errors || {};
    expect(errors['required']).toBeTruthy();
  });
});
