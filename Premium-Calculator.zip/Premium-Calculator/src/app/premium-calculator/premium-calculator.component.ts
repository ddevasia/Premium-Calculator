import { Component, OnInit } from "@angular/core";
import { FormControl, FormGroup, Validators } from "@angular/forms";

import { Occupation, Rating } from "../model/ocupation";
import { PremiumService } from '../premium.service';
import { Ocupations } from '../mocks/ocupationMockData';

@Component({
  selector: "premium-calculator",
  templateUrl: "./premium-calculator.component.html",
  styleUrls: ["./premium-calculator.component.css"]
})
export class PremiumCalculator implements OnInit {
  form: FormGroup;
  loading = false;
  submitted = false;
  premiumPerMonth;
  occupations: Occupation[] = Ocupations;
  premiumService = new PremiumService();

  ngOnInit() {
    this.form = new FormGroup({
      name: new FormControl("", Validators.required),
      age: new FormControl("", Validators.required),
      dob: new FormControl("", Validators.required),
      occupation: new FormControl("", Validators.required),
      totalAmount: new FormControl("", Validators.required)
    });   
  }

  onSubmit() { }

  get f() {
    return this.form.controls;
  }

  changeOccupation($event) {
    this.submitted = true;
    if (this.form.status === "VALID") {
      this.premiumPerMonth = (this.premiumService.calculatePremium(this.f.totalAmount.value, this.f.occupation.value, this.f.age.value));        
    }
  }  
}

