import { Occupation, Rating } from '../model/ocupation'

export const Ocupations: Occupation[]= [
  { name: "Cleaner", rating: Rating.LIGHT_MANUAL, factor: 1.5 },
  { name: "Doctor", rating: Rating.PROFESSIONAL, factor: 1 },
  { name: "Author", rating: Rating.WHITE_COLLAR, factor: 1.25 },
  { name: "Farmer", rating: Rating.HEAVY_MANUAL, factor: 1.75 },
  { name: "Mechanic", rating: Rating.HEAVY_MANUAL, factor: 1.75 },
  { name: "Florist", rating: Rating.LIGHT_MANUAL, factor: 1.5 }
];
