import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PremiumService {

  constructor() { }

  calculatePremium(totalAmount: string, occupation:string,age:string): string {
     return (((parseFloat(totalAmount) *
      parseFloat(occupation) *
      parseInt(age)) /
      (1000 * 12)
      ).toFixed(2));
  }

  
}
