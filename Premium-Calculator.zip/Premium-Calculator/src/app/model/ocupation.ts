export enum Rating {
  LIGHT_MANUAL = "Light Manual",
  PROFESSIONAL = "Professional",
  WHITE_COLLAR = "White Collar",
  HEAVY_MANUAL = "Heavy Manual"
}

export interface Occupation {
  name: string;
  rating: Rating;
  factor: number;
}
