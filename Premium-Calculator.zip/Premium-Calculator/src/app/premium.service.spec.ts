import { TestBed } from '@angular/core/testing';

import { PremiumService } from './premium.service';
import { PremiumCalculator } from "./premium-calculator/premium-calculator.component";
    
describe('PremiumService', () => {

  let mockPremiumService;
  beforeEach(() => TestBed.configureTestingModule({
    declarations: [PremiumCalculator],
    providers: [PremiumService],
    schemas: []
  }).compileComponents());  

   it('should be created', () => {
    const service: PremiumService = TestBed.get(PremiumService);
    expect(service).toBeTruthy();
  });
  
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PremiumCalculator],
      providers: [{
        provide: PremiumService,
        useValue: jasmine.createSpyObj('PremiumService', ['calculatePremium'])
      }],      
    });
    mockPremiumService = TestBed.get(PremiumService);

    mockPremiumService.getCustomer.and.returnValue("150.50");
  })

});
