import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { AppComponent } from "./app.component";
import { PremiumCalculator } from "./premium-calculator/premium-calculator.component";
import { DlDateTimeDateModule, DlDateTimePickerModule } from 'angular-bootstrap-datetimepicker';

@NgModule({
  imports: [BrowserModule, FormsModule, ReactiveFormsModule, DlDateTimeDateModule,DlDateTimePickerModule],
  declarations: [AppComponent, PremiumCalculator],
  bootstrap: [AppComponent]
})
export class AppModule { }
