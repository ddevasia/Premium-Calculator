Project Details

1.Project is in Angular8
2.premium-calculator.html has the UI design.
3.premium-calculator.component is the component for the UI logic.
4.premium.service is the service class for the calculation. 
5.ocupation in models folder is the model class.
6.ocupationMockData in mocks folder has the mock data for the dropdown control.
7.unit tests are in the spec files(premiumservice.spec.ts,premium-calculator.component.spec.ts)